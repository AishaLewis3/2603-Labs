import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * ID - 816042177
 *
 */
public class InsuredPerson
{
    private String fullName;
    private LocalDate DOB;
    private ArrayList<Claim> claims;
    private double disbursements;
    public InsuredPerson(String fullName, String DOB){
        this.fullName = fullName;
        String cleanedDOB = removeOrdinalSuffix(DOB);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMMM yyyy");
        this.DOB = LocalDate.parse(cleanedDOB, formatter);
        this.claims = new ArrayList<>();
    }
    public String getFullName(){
        return fullName;
    }
    public LocalDate getDOB(){
        return DOB;
    }
    public ArrayList<Claim> getClaims(){
        return claims;
    }
    public int getAge(){
         return LocalDate.now().getYear() - DOB.getYear();
    }
    public double getDisbursements(){
        return disbursements;
    }
    public String getInitials(){
        String[] names = fullName.split(" ");
        String initials = "";
        for (String name : names) {
            if (!name.isEmpty()) {
                initials += name.charAt(0);
            }
        }
        return initials.toUpperCase();
    }
    public void addClaim(String claimDate, double claimValue){
        Claim newClaim = new Claim(claimDate, claimValue, getInitials());
        claims.add(newClaim);
    }
    public void recordDisbursements(double value){
        if (value > 0) {
            disbursements += value;
        }
    }
    private String removeOrdinalSuffix(String date) {
        return date.replaceAll("(\\d+)(st|nd|rd|th)", "$1");
    }
     public String toString() {
        StringBuilder sentence = new StringBuilder();
        sentence.append(fullName).append(" ").append(DOB).append(" ").append(getAge()).append("YRS\n");
        for (Claim claim : claims) {
            sentence.append(claim.toString()).append("\n");
        }
        sentence.append("DISBURSEMENTS: $").append(String.format("%.2f", disbursements));
        return sentence.toString();
    }
}
