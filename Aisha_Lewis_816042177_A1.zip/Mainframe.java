import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
/**
 * ID - 816042177
 *
 */
public class Mainframe
{
    private ArrayList<InsuredPerson> clients;
    private ArrayList<Claim> client_claim;
    int MAX_DATE = 60;
    public Mainframe()
    {
        client_claim = new ArrayList<Claim>();
        clients = new ArrayList<InsuredPerson>();
    }
    public void addClient(String fullName, String DOB){
        LocalDate birthdate = convertDate(DOB);
        if (DOB != null) {
            InsuredPerson person = new InsuredPerson(fullName, DOB);
            clients.add(person);
        } else {
            System.out.println("Invalid date format for DOB");
        }
    }
    public void addClaim(int clientIndex, String claimDate, double claimValue){
        if (clientIndex >= 0 && clientIndex < clients.size()) {
            InsuredPerson person = clients.get(clientIndex);
            person.addClaim(claimDate, claimValue);
            String cleanedDate = removeOrdinalSuffix(claimDate);
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMMM yyyy");
                LocalDate date = LocalDate.parse(cleanedDate, formatter);
    
                LocalDate current = LocalDate.now();
                if (!date.isBefore(current.minusDays(MAX_DATE)) && !date.isAfter(current)) {
                    person.recordDisbursements(claimValue);
                }
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format for claimDate: " + claimDate);
            }
        } else {
            System.out.println("Invalid Index");
        }
    }
    public boolean validateDayRange(LocalDate claimDate){
        LocalDate current = LocalDate.now();
        if (!claimDate.isBefore(current.minusDays(MAX_DATE)) && !claimDate.isAfter(current)) {
                return true;
        }
        return false;
    }
    public void processClaims(){
        LocalDate currentDate = LocalDate.now();
        for (InsuredPerson client : clients) {
            for (Claim claim : client.getClaims()) {
                LocalDate claimDate = claim.getClaimDate();
                if (claimDate != null && validateDayRange(claimDate)) {
                    claim.disburse(true);
                } else {
                    claim.disburse(false);
                    claim.setClaimNote("CLAIM OLDER THAN 60 DAYS / INVALID DATE");
                }
            }
        }
    }
    public String getReports(){
        String report = "";
        for (InsuredPerson client : clients) {
            report += client.toString() + "\n";
            for (Claim claim : client.getClaims()) {
                report += claim.toString() + "\n";
            }
        }
        return report;
    }
    public LocalDate convertDate(String dateString){
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd['st']['nd']['rd']['th'] MMMM yyyy");
            return LocalDate.parse(dateString, formatter);
        } catch (DateTimeParseException e) {
            return null;
        }
    }
    private String removeOrdinalSuffix(String date) {
        return date.replaceAll("(\\d+)(st|nd|rd|th)", "$1");
    }
}
