import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
/**
 * ID: 816042177
 * 
 *
 */
public class Claim{
    private String claimNo;
    private static int claimCounter;
    private LocalDate claimDate;
    private LocalDate processedDate;
    private double claimValue;
    private boolean disbursed = false;
    private String claimNote = "";
    public Claim(String claimDate, double claimValue, String claimOwnerInitials){
        String cleanedDOB = removeOrdinalSuffix(claimDate);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMMM yyyy");
        this.claimDate = LocalDate.parse(cleanedDOB, formatter);
        this.claimValue = claimValue;
        claimCounter++;
        this.claimNo = claimOwnerInitials + claimCounter;
    }
    public String getClaimNo(){
        return claimNo;
    }
    public LocalDate getClaimDate(){
        return claimDate;
    }
    public double getClaimValue(){
        return claimValue;
    }
    public void disburse(boolean disbursed){
        this.disbursed = disbursed;
        this.processedDate = LocalDate.now();
    }
    public void setClaimNote(String note){
        this.claimNote = this.claimNote + "\t"+ note;
    }
    private String removeOrdinalSuffix(String date) {
        return date.replaceAll("(\\d+)(st|nd|rd|th)", "$1");
    }
    public String toString(){ 
        String disbursedStatus = disbursed ? "Y" : "N";
        StringBuilder sentence = new StringBuilder();
        sentence.append("CLAIM NO: ").append(getClaimNo()).append(" ").append(getClaimDate()).append(" $").append(getClaimValue()).append(" PAID: ").append(disbursedStatus).append(" PROCESSED ON: ").append(processedDate);
        if (!claimNote.isEmpty()) {
            sentence.append("\nNOTE: ").append(claimNote);
        }
        return sentence.toString();
    }
}