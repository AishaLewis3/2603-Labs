import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
/**
 * ID - 816042177
 *
 */
public class InsuranceApplication
{
    public static void main(String[] args) {
        Mainframe frame = new Mainframe();
        try{
            File infile = new File("data.txt");
            Scanner readFile = new Scanner(infile);
            while(readFile.hasNextLine()){
                String data =readFile.nextLine();
                if(!data.isEmpty()){
                    char firstChar = data.charAt(0);
                    if(Character.isLetter(firstChar)){
                        ArrayList<String> words = new ArrayList<>();
                        for (String word : data.split(", ")){
                            words.add(word);
                        }
                        frame.addClient(words.get(0), words.get(1));
                    }else{
                        ArrayList<String> info = new ArrayList<>();
                        for (String inform : data.split(", ")){
                            info.add(inform);
                        }
                        frame.addClaim(Integer.parseInt(info.get(0)), info.get(1), Double.parseDouble(info.get(2)));
                    }
                }
            }
            frame.processClaims();
            System.out.println(frame.getReports());
            readFile.close();
        } catch(FileNotFoundException e){
            System.out.println("An error occured");
            e.printStackTrace();
        }
    }
}
/** Citations: 
 * 1. file info - https://www.w3schools.com/java/java_files_read.asp
 * 2. LocalDate - https://www.geeksforgeeks.org/java-time-localdate-class-in-java/ 
 * 3. ArrayList - https://www.geeksforgeeks.org/arraylist-in-java
 * 4. ArrayList + Index - https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/ArrayList.html 
 * 5. Remove Ordinals - https://stackoverflow.com/questions/15403383/how-to-remove-ordinal-value-in-java
*/